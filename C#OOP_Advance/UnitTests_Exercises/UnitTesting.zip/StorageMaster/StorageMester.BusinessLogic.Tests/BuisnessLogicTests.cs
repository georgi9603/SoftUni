﻿using NUnit.Framework;
using NUnit.Framework.Internal;

namespace StorageMester.BusinessLogic.Tests
{
    [TestFixture]
    public class BuisnessLogicTests
    {
    }
}