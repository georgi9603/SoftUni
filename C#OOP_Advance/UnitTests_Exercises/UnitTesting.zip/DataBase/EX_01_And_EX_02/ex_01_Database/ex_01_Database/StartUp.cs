﻿using System;

namespace ex_01_Database
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
