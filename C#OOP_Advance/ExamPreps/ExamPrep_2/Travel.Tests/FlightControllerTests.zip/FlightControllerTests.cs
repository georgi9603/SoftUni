namespace Travel.Tests
{
    using NUnit.Framework;

    [TestFixture]
    public class FlightControllerTests
    {
        [Test]
        public void TakeOffNormally()
        {
            IItem item = new CellPhone();
            IPassenger passenger = new Passenger("Gosho");
            IBag bag = new Bag(passenger, new IItem[] { item });
            passenger.Bags.Add(bag);
            IAirplane airplane = new LightAirplane();
            airplane.AddPassenger(passenger);
            IAirport airport = new Airport();
            airport.AddPassenger(passenger);
            ITrip trip = new Trip("tuk", "tam", airplane);
            trip.Complete();
            airport.AddTrip(trip);
            IFlightController flightController = new FlightController(airport);
            var actualResult = flightController.TakeOff();
            var expectedResult = "Confiscated bags: 0 (0 items) => $0";

            Assert.AreEqual(actualResult, expectedResult);

            IItem item2 = new CellPhone();
            IPassenger passenger2 = new Passenger("Gosho");
            IBag bag2 = new Bag(passenger2, new IItem[] { item2 });
            passenger2.Bags.Add(bag2);
            IAirplane airplane2 = new LightAirplane();
            for (int i = 0; i < 6; i++)
            {
                airplane2.AddPassenger(passenger2);
            }
            IAirport airport2 = new Airport();
            airport2.AddPassenger(passenger2);
            ITrip trip2 = new Trip("tuk", "tam", airplane2);
            airport2.AddTrip(trip2);
            IFlightController flightController2 = new FlightController(airport2);
            var actualResult2 = flightController2.TakeOff();
            var expectedResult2= "tuktam2:\r\nOverbooked! Ejected Gosho\r\nConfiscated 1 bags ($700)\r\nSuccessfully transported 5 passengers from tuk to tam.\r\nConfiscated bags: 1 (1 items) => $700";

            Assert.AreEqual(actualResult2, expectedResult2);

        }

        
    }
}
