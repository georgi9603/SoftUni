﻿public class Amethyst : Gem
    {
        public Amethyst(GemClarity clarity) 
            : base(clarity, 2, 8, 4)
        {
        }
    }