﻿public interface IGemFactory
    {
        IGem CreateGem(string clarity, string gemType);
    }