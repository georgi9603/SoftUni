﻿public interface IRareWeapon
    {
        WeaponRarity Rarity { get; }
    }