﻿
public interface IQualitativeGem
    {
        GemClarity Clarity { get; }
    }