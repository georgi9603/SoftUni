﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace GenericBoxOfString
{
    class Program
    {
        static void Main(string[] args)
        {
            int number = int.Parse(Console.ReadLine());

            List<string> listItems = new List<string>();

            for (int i = 0; i < number; i++)
            {
                string result = Console.ReadLine();

                listItems.Add(result);
            }

            string compareInput = Console.ReadLine();
            listItems.Add(compareInput);

            Box<string> box = new Box<string>(listItems);

            Console.WriteLine(box.compareItems());
        }
    }
}
