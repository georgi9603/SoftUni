﻿namespace AdoNetExercises
{
    public static class Configuration
    {
        public const string ConnectionString = "Server=DESKTOP-QLVMHQA\\SQLEXPRESS;Database=MinionsDB;Integrated Security=True";
    }
}