﻿namespace P03_FootballBetting.Data
{
    public class Configuration
    {
        public const string connectionString = 
            @"Server=DESKTOP-P616POQ\SQLEXPRESS;Database=FootballBetting;Trusted_Connection=True;";
    }
}