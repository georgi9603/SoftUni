﻿namespace P01_StudentSystem.Data
{
    public class Configuration
    {
        public const string connectionString = "Server=DESKTOP-P616POQ" + @"\SQLEXPRESS;Database=StudentSystem;Integrated Security=True;";
    }
}