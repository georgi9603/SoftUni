﻿namespace BillsPaymentSystem.App.Core.Commands
{
    public class WithdrawCommand
    {
    }
}