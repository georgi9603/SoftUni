﻿namespace BillsPaymentSystem.App.Core.Commands
{
    public class DepositCommand
    {
    }
}