﻿namespace BillsPaymentSystem.Models.Enums
{
    public enum PaymentType
    {
        BankAccount = 0,
        CreditCard = 1
    }
}