﻿namespace BillsPaymentSystem.Data
{
    internal static class Configuration
    {
        internal static string connectionString =
            @"Server=DESKTOP-P616POQ\SQLEXPRESS;Database=BillsPaymentSystem;Integrated Security=True;";
    }
}